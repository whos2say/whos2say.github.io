# Who's to Say ? Foundation — Site
This is a single-file site designed for GitHub Pages. Upload `index.html` to the root of your repository.

## Quick start (User site)
1. Create a new repository named `<your-username>.github.io` (public).
2. Upload `index.html` to the root and commit.
3. Visit `https://<your-username>.github.io` after a minute.

## Quick start (Project site)
1. Create any repository name (public).
2. Upload `index.html` to the root and commit.
3. In **Settings → Pages**, set **Build and deployment** to `Deploy from a branch`, branch `main`, folder `/ (root)`.
4. Your site will be live at `https://<your-username>.github.io/<repo-name>/`.
